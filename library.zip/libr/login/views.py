from django.shortcuts import render

# Create your views here.
def home(request):
    return render(request, 'index.html')

def login(request):
    return render(request, 'loginindex.html')

def pd(request):
    return render(request, 'pd.html')

def ib(request):
    return render(request, 'ib.html')